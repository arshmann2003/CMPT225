#ifndef StackInterface_H
#define StackInterface_H

template <typename E>
class Stack { 
public: 
    virtual int size() const = 0; 
    bool empty() const; 
    const E& top() const throw(StackEmpty); 
    void push(const E& e); 
    void pop() throw(StackEmpty); 
};

#endif
