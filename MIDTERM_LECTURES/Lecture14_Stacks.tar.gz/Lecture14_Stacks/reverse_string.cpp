#include <iostream>
#include <vector>
#include "ArrayStack.h"
#include "LinkedStack.h"

using namespace std;

void reverse_with_ArrayStack(vector<string>& V) {    // reverse a vector
  ArrayStack<string> S(V.size());
  for (int i = 0; i < V.size(); i++) // push elements onto stack
    S.push(V[i]);
  for (int i = 0; i < V.size(); i++) { // pop them in reverse order
    V[i] = S.top(); 
    S.pop();
  }
}

void reverse_with_LinkedStack(vector<string>& V) {    // reverse a vector
  LinkedStack S;
  for (int i = 0; i < V.size(); i++) // push elements onto stack
    S.push(V[i]);
  for (int i = 0; i < V.size(); i++) { // pop them in reverse order
    V[i] = S.top(); 
    S.pop();
  }
}


int main(int argc, char** argv){
  if (argc!=2){
	cout << "Usage: executable.o stack_implementation" <<endl << "where stack_implementation can be either ArrayStack or LinkedStack" << endl;
	return 1;
  }

  vector<string> V = {"Hello!", "My", "name", "is", "Golnar", "."};

  string stack_implementation = argv[1];

  if (stack_implementation.compare("ArrayStack")==0)
	reverse_with_ArrayStack(V);
  else if (stack_implementation.compare("LinkedStack")==0)
	reverse_with_LinkedStack(V);
  else{
	cout << "Usage: executable.o stack_implementation" <<endl << "where stack_implementation can be either ArrayStack or LinkedStack" << endl;
        return 1;
  }

  for (auto itr=V.begin(); itr!=V.end(); ++itr)
	cout << *itr <<" ";
  cout << endl;

  return 0;
}




