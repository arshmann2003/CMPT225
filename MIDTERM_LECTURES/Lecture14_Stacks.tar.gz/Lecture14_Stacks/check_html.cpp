#include <vector>
#include <fstream>
#include "LinkedStack.h"

using namespace std;

vector<string> getHtmlTags(string fname) {        // store tags in a vector
  ifstream inf;
  inf.open(fname);
 
  vector<string> tags;                            // vector of html tags
  string line;
  while (getline(inf,line).good()) {              // read until end of file
    int pos = 0;
    int ts = line.find("<", pos);                 // possible tag start
    while (ts != string::npos) {                  // repeat until end of string
       int te = line.find(">", ts+1);             // scan for tag end
       tags.push_back(line.substr(ts, te-ts+1));  // append tag to the vector
       pos = te + 1;                              // advance our position
       ts = line.find("<", pos);
    }
  } 
 
  inf.close();
  return tags;                                    // return vector of tags
}


// check for matching tags
bool isHtmlMatched(const vector<string>& tags) {
   LinkedStack S;                                // stack for opening tags
   for (auto p = tags.begin(); p != tags.end(); ++p) {
      if (p->at(1) != '/')                       // opening tag?
         S.push(*p);                             // push it on the stack
      else {                                     // else must be closing tag
         if (S.empty()) 
            return false;                        // nothing to match - failure
         string open = S.top().substr(1);        // opening tag excluding ’<’
         string close = p->substr(2);            // closing tag excluding ’</’
         if (open.compare(close) != 0) 
            return false;                        // fail to match
         else 
            S.pop();                             // pop matched element
      }
   }
   if (S.empty()) 
      return true;                               // everything matched - good
   else 
      return false;                              // some unmatched - bad
}

int main(int argc, char** argv) {                // main HTML tester
   if (argc!=2){
   	cout << "Usage: executable.o page.html" << endl;
	return 1;
   }

   if (isHtmlMatched(getHtmlTags(argv[1])))      // get tags and test them
       cout << "The input file is a matched HTML document." << endl;
   else
       cout << "The input file is not a matched HTML document." << endl;
}
