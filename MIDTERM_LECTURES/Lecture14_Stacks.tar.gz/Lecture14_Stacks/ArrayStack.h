#ifndef ArrayStack_H
#define ArrayStack_H

#include "StackExceptions.h"
#include "StackInterface.h"

template <typename E>
class ArrayStack :Stack<E> { 
public: 
    ArrayStack(int capacity=1000):a_(new E[capacity]), capacity_(capacity), top_(-1){}

    int size() const {return top_+1;} 

    bool empty() const {return top_<0;} 

    const E& top() const throw(StackEmpty){
        if (empty())
                throw StackEmpty("calling top() on an empty stack!");
        return a_[top_];
    }

    void push(const E& e){
        if (top_>=capacity_)
                throw StackEmpty("can't push into a full stack!");
        a_[++top_] = e;

    }

    void pop() throw(StackEmpty){
        if (empty())
                throw StackEmpty("calling pop() on an empty stack!");
        top_--;
    }


private:
    E* a_;
    int top_;
    int capacity_;
};

#endif
